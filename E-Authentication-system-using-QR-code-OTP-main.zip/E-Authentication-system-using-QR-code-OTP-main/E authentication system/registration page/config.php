<?php

    $connect = mysqli_connect("localhost", "root", "", "auth") or die(mysqli_error($connect));

?>